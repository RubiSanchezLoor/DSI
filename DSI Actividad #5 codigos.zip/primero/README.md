#
abrir en vs code y ejecutar con live serve