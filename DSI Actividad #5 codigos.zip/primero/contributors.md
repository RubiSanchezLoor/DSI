:construction:
## Folder Structure

```
├───css
│   └───assets
├───favicon
├───images
├───js
└───pages

```